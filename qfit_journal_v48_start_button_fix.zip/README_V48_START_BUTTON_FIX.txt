QFit Journal v48 — Start Button Fix

Что исправлено:
1. Исправлено падение app.js из-за отсутствующего startBtn: обработчик теперь безопасный.
2. Кнопке «Начать» на HTML-стартовом экране возвращён id="startBtn".
3. Убрана зависимость только от inline onclick.
4. Версии файлов обновлены до v48 для обхода старого кэша GitHub Pages / PWA.
5. Добавлен безопасный cache-clean helper: параметр ?clear=1 чистит service worker/caches, но НЕ трогает localStorage с программами и журналом.

Ссылка после загрузки на GitHub Pages:
https://jnruslan-bot.github.io/qfit-journal/?v=48&clear=1

Загружать на GitHub нужно содержимое папки, а не zip-файл.
