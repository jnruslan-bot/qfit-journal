QFit Journal v46 — Responsive + Cache Fix

Главное исправление:
1. Развязаны два режима отображения:
   - компьютер / широкая веб-версия — аккуратный телефон-макет по центру;
   - телефон / PWA — полноэкранное приложение без «телефона внутри телефона».
2. Стартовый экран больше не использует PNG-макет как основной интерфейс.
3. Обновлены версии файлов до ?v=46.
4. Добавлен аварийный сброс кэша через ссылку:
   https://jnruslan-bot.github.io/qfit-journal/?v=46&clear=1
5. Service Worker обновлён до qfit-journal-v46-responsive-cache-fix.

Как загрузить:
1. Распакуйте архив.
2. В GitHub откройте репозиторий qfit-journal.
3. Нажмите Add file → Upload files.
4. Перетащите ВСЁ содержимое папки qfit_journal_v46_responsive_cache_fix:
   index.html, app.js, styles.css, manifest.json, sw.js и папку assets.
5. Нажмите Commit changes.
6. Дождитесь обновления GitHub Pages.
7. Первый раз откройте:
   https://jnruslan-bot.github.io/qfit-journal/?v=46&clear=1
8. Дальше открывайте:
   https://jnruslan-bot.github.io/qfit-journal/?v=46

На телефоне:
- старую иконку установленного приложения лучше удалить;
- открыть ссылку ?v=46&clear=1 в Chrome;
- потом установить заново: меню Chrome ⋮ → Установить приложение / Добавить на главный экран.
